# 📚 Folio — Book Shop Management System v2

A **modern, integrated single-page application** where Flask serves both the REST API and the complete frontend from one server. No separate file server needed.

## ✨ What's New in v2

- **Single URL** — open `http://localhost:5000` and everything works
- **Client-side routing** — pages load instantly with `#hash` navigation, no page reloads
- **Modern dark editorial design** — Playfair Display + DM Sans, dark ink palette, gold accents
- **Single HTML file** — entire 1400-line SPA frontend in one `index.html`
- **Integrated invoice viewer** — printable invoices open inline as modals
- **Real-time badge** — inventory nav badge shows low-stock count automatically

## 🚀 Quick Start

```bash
# 1. Setup MySQL database
mysql -u root -p < backend/database/schema.sql
mysql -u root -p bookshop_db < backend/database/seed_data.sql

# 2. Set your MySQL password in backend/config.py
# Edit: DB_PASSWORD = 'your-password'

# 3. Install Python dependencies
cd backend
pip install -r requirements.txt

# 4. Create demo users (hashed passwords)
python seed_users.py

# 5. Start the server
python app.py

# 6. Open in browser
# → http://localhost:5000
```

## 🔑 Demo Credentials

| Role  | Username | Password  |
|-------|----------|-----------|
| Admin | admin    | admin123  |
| Staff | staff1   | staff123  |

## 🏗 Architecture

```
bookshop-v2/
├── backend/
│   ├── app.py          ← Serves BOTH /api/* AND the SPA frontend
│   ├── frontend/       ← Static files served by Flask
│   └── ...             ← Same backend as v1
└── frontend/
    └── index.html      ← Entire SPA: 1400 lines, one file
```

Flask serves `frontend/index.html` for all non-API routes. The SPA uses `#hash` routing to navigate between pages without reloads.

## 📐 How It Works

1. User visits `http://localhost:5000` → Flask serves `index.html`
2. JavaScript boots, checks for JWT in `localStorage`
3. If logged in → renders dashboard immediately
4. Navigation calls `nav('books')` → updates URL to `#books`, re-renders content area
5. All data fetched from `http://localhost:5000/api/*` endpoints
6. Modals, toasts, and state managed entirely in JS — zero page refreshes
