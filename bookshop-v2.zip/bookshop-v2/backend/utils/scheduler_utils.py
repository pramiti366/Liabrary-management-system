"""
scheduler_utils.py - Background Scheduler Utilities
=====================================================
Task queue management for the background scheduler.
"""

import threading
from datetime import datetime
from collections import deque


# ── Thread-safe task queue ────────────────────────────────────────────────────
_task_queue = deque()
_queue_lock = threading.Lock()


def add_task(task_name: str, scheduled_time: str, func, args=None):
    """
    Add a task to the scheduler queue.

    Args:
        task_name      : Human-readable name for logging
        scheduled_time : "HH:MM" string (24-hour format)
        func           : Python callable to execute
        args           : Optional list of arguments for func
    """
    with _queue_lock:
        _task_queue.append({
            'name':      task_name,
            'time':      scheduled_time,   # "HH:MM"
            'func':      func,
            'args':      args or [],
            'last_run':  None,             # Date of last execution (prevents double-run)
        })
    print(f"[Scheduler] Task queued: '{task_name}' at {scheduled_time}")


def get_pending_tasks():
    """Return a snapshot of all tasks in the queue."""
    with _queue_lock:
        return list(_task_queue)


def check_and_run_tasks():
    """
    Compare each task's scheduled time with current system time.
    Execute the task if the time matches and it hasn't run today.

    Algorithm:
      1. Get current HH:MM and today's date
      2. Loop through every task
      3. If task time == current time AND last_run != today → execute
      4. Mark last_run = today so it won't re-run this minute
    """
    now       = datetime.now()
    now_time  = now.strftime('%H:%M')    # "14:30"
    today_str = now.strftime('%Y-%m-%d') # "2024-01-15"

    with _queue_lock:
        for task in _task_queue:
            if task['time'] == now_time and task['last_run'] != today_str:
                print(f"[Scheduler] ▶ Running task: '{task['name']}'")
                try:
                    task['func'](*task['args'])
                    task['last_run'] = today_str
                    print(f"[Scheduler] ✔ Task completed: '{task['name']}'")
                except Exception as e:
                    print(f"[Scheduler] ✘ Task failed: '{task['name']}' → {e}")
