"""
auth_utils.py - Authentication Utilities
=========================================
JWT token generation/verification and password hashing helpers.
"""

import jwt
import bcrypt
from datetime import datetime, timezone
from functools import wraps
from flask import request, jsonify
import sys, os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import ActiveConfig


# ── Password Hashing ──────────────────────────────────────────────────────────

def hash_password(plain_password: str) -> str:
    """Hash a plain-text password using bcrypt."""
    salt = bcrypt.gensalt(rounds=12)
    hashed = bcrypt.hashpw(plain_password.encode('utf-8'), salt)
    return hashed.decode('utf-8')


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Check a plain-text password against a bcrypt hash."""
    return bcrypt.checkpw(
        plain_password.encode('utf-8'),
        hashed_password.encode('utf-8')
    )


# ── JWT Tokens ────────────────────────────────────────────────────────────────

def generate_token(user_id: int, username: str, role: str) -> str:
    """Generate a signed JWT for the given user."""
    payload = {
        'user_id':  user_id,
        'username': username,
        'role':     role,
        'iat':      datetime.now(timezone.utc),
        'exp':      datetime.now(timezone.utc) + ActiveConfig.JWT_ACCESS_TOKEN_EXPIRES,
    }
    token = jwt.encode(payload, ActiveConfig.JWT_SECRET_KEY, algorithm='HS256')
    return token


def decode_token(token: str) -> dict:
    """
    Decode and verify a JWT.
    Returns the payload dict, or raises jwt.ExpiredSignatureError / jwt.InvalidTokenError.
    """
    return jwt.decode(token, ActiveConfig.JWT_SECRET_KEY, algorithms=['HS256'])


# ── Route Decorators ──────────────────────────────────────────────────────────

def login_required(f):
    """
    Decorator: protects a route — requires a valid Bearer token.
    Injects `current_user` dict into the wrapped function.
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization', '')
        if not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Missing or invalid Authorization header'}), 401

        token = auth_header.split(' ', 1)[1]
        try:
            current_user = decode_token(token)
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token has expired. Please login again.'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Invalid token.'}), 401

        return f(current_user=current_user, *args, **kwargs)
    return decorated


def admin_required(f):
    """
    Decorator: protects a route — requires a valid token AND admin role.
    """
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization', '')
        if not auth_header.startswith('Bearer '):
            return jsonify({'error': 'Missing or invalid Authorization header'}), 401

        token = auth_header.split(' ', 1)[1]
        try:
            current_user = decode_token(token)
        except jwt.ExpiredSignatureError:
            return jsonify({'error': 'Token has expired. Please login again.'}), 401
        except jwt.InvalidTokenError:
            return jsonify({'error': 'Invalid token.'}), 401

        if current_user.get('role') != 'admin':
            return jsonify({'error': 'Admin access required.'}), 403

        return f(current_user=current_user, *args, **kwargs)
    return decorated
