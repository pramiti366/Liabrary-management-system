"""
book_model.py - Book Database Operations
=========================================
All database interactions for the books table.
"""

from database.db_connection import execute_query


def get_all_books(search=None, category_id=None, author=None):
    """
    Return all books with optional filters.
    Joins categories and publishers for display names.
    """
    query = """
        SELECT b.*, c.category_name, p.publisher_name
        FROM books b
        LEFT JOIN categories c ON b.category_id = c.category_id
        LEFT JOIN publishers p ON b.publisher_id = p.publisher_id
        WHERE 1=1
    """
    params = []

    if search:
        query += " AND (b.title LIKE %s OR b.author LIKE %s OR b.isbn LIKE %s)"
        like = f"%{search}%"
        params.extend([like, like, like])

    if category_id:
        query += " AND b.category_id = %s"
        params.append(category_id)

    if author:
        query += " AND b.author LIKE %s"
        params.append(f"%{author}%")

    query += " ORDER BY b.title ASC"
    return execute_query(query, tuple(params), fetch=True)


def get_book_by_id(book_id: int):
    """Return single book with category/publisher names."""
    rows = execute_query("""
        SELECT b.*, c.category_name, p.publisher_name
        FROM books b
        LEFT JOIN categories c ON b.category_id = c.category_id
        LEFT JOIN publishers p ON b.publisher_id = p.publisher_id
        WHERE b.book_id = %s
    """, (book_id,), fetch=True)
    return rows[0] if rows else None


def create_book(data: dict):
    """Insert a new book. Returns new book_id."""
    return execute_query(
        """INSERT INTO books
           (title, author, isbn, category_id, publisher_id, price, stock_quantity, low_stock_threshold)
           VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
        (
            data['title'], data['author'], data.get('isbn'),
            data.get('category_id'), data.get('publisher_id'),
            data['price'], data.get('stock_quantity', 0),
            data.get('low_stock_threshold', 5)
        )
    )


def update_book(book_id: int, data: dict):
    """Update an existing book's fields."""
    execute_query(
        """UPDATE books SET
           title=%s, author=%s, isbn=%s, category_id=%s, publisher_id=%s,
           price=%s, stock_quantity=%s, low_stock_threshold=%s
           WHERE book_id=%s""",
        (
            data['title'], data['author'], data.get('isbn'),
            data.get('category_id'), data.get('publisher_id'),
            data['price'], data.get('stock_quantity', 0),
            data.get('low_stock_threshold', 5), book_id
        )
    )


def delete_book(book_id: int):
    """Hard delete a book record."""
    execute_query("DELETE FROM books WHERE book_id = %s", (book_id,))


def update_stock(book_id: int, quantity_change: int):
    """
    Adjust stock by quantity_change (positive = add, negative = subtract).
    Raises an error if stock would go below zero.
    """
    execute_query(
        """UPDATE books
           SET stock_quantity = stock_quantity + %s
           WHERE book_id = %s AND (stock_quantity + %s) >= 0""",
        (quantity_change, book_id, quantity_change)
    )


def get_low_stock_books():
    """Return books where stock_quantity <= low_stock_threshold."""
    return execute_query(
        """SELECT b.*, c.category_name
           FROM books b
           LEFT JOIN categories c ON b.category_id = c.category_id
           WHERE b.stock_quantity <= b.low_stock_threshold
           ORDER BY b.stock_quantity ASC""",
        fetch=True
    )
