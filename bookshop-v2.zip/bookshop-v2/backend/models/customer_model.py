"""
customer_model.py - Customer Database Operations
================================================
"""

from database.db_connection import execute_query


def get_all_customers(search=None):
    """Return all customers with optional name/phone search."""
    query  = "SELECT * FROM customers WHERE 1=1"
    params = []
    if search:
        query += " AND (name LIKE %s OR phone LIKE %s OR email LIKE %s)"
        like   = f"%{search}%"
        params.extend([like, like, like])
    query += " ORDER BY name ASC"
    return execute_query(query, tuple(params), fetch=True)


def get_customer_by_id(customer_id: int):
    rows = execute_query(
        "SELECT * FROM customers WHERE customer_id = %s",
        (customer_id,), fetch=True
    )
    return rows[0] if rows else None


def create_customer(data: dict):
    return execute_query(
        "INSERT INTO customers (name, phone, email, address) VALUES (%s, %s, %s, %s)",
        (data['name'], data.get('phone'), data.get('email'), data.get('address'))
    )


def update_customer(customer_id: int, data: dict):
    execute_query(
        "UPDATE customers SET name=%s, phone=%s, email=%s, address=%s WHERE customer_id=%s",
        (data['name'], data.get('phone'), data.get('email'), data.get('address'), customer_id)
    )


def get_customer_purchase_history(customer_id: int):
    """Return all invoices for a customer with item details."""
    return execute_query("""
        SELECT s.invoice_id, s.sale_date, s.total_amount, s.payment_method,
               si.quantity, si.unit_price, b.title AS book_title
        FROM sales s
        JOIN sale_items si ON s.invoice_id = si.invoice_id
        JOIN books b ON si.book_id = b.book_id
        WHERE s.customer_id = %s
        ORDER BY s.sale_date DESC
    """, (customer_id,), fetch=True)
