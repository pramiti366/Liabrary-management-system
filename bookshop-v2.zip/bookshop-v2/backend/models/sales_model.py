"""
sales_model.py - Sales & Invoice Database Operations
=====================================================
"""

from database.db_connection import execute_query, get_connection


def create_sale(customer_id, user_id, items, discount_percent=0, payment_method='cash', notes=''):
    """
    Create a complete sale with all line items in a single transaction.

    Args:
        customer_id     : FK to customers (can be None for walk-in)
        user_id         : FK to users (staff who made the sale)
        items           : list of {'book_id', 'quantity', 'unit_price'}
        discount_percent: percentage discount (0-100)
        payment_method  : 'cash' | 'card' | 'online'
        notes           : optional text

    Returns:
        invoice_id (int)
    """
    conn   = None
    cursor = None
    try:
        conn   = get_connection()
        cursor = conn.cursor(dictionary=True)

        # ── Calculate totals ──────────────────────────────────────────────────
        subtotal = sum(float(item['unit_price']) * int(item['quantity']) for item in items)
        discount_amount = subtotal * (float(discount_percent) / 100)
        total_amount    = subtotal - discount_amount

        # ── Insert invoice header ─────────────────────────────────────────────
        cursor.execute(
            """INSERT INTO sales
               (customer_id, user_id, subtotal, discount_percent, discount_amount, total_amount, payment_method, notes)
               VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
            (customer_id, user_id, subtotal, discount_percent, discount_amount, total_amount, payment_method, notes)
        )
        invoice_id = cursor.lastrowid

        # ── Insert line items + update stock ─────────────────────────────────
        for item in items:
            book_id    = item['book_id']
            quantity   = int(item['quantity'])
            unit_price = float(item['unit_price'])
            total_price = unit_price * quantity

            cursor.execute(
                "INSERT INTO sale_items (invoice_id, book_id, quantity, unit_price, total_price) "
                "VALUES (%s, %s, %s, %s, %s)",
                (invoice_id, book_id, quantity, unit_price, total_price)
            )

            # Reduce stock
            cursor.execute(
                "UPDATE books SET stock_quantity = stock_quantity - %s WHERE book_id = %s",
                (quantity, book_id)
            )

            # Log inventory movement
            cursor.execute(
                """INSERT INTO inventory
                   (book_id, change_type, quantity_change, quantity_before, quantity_after, notes, created_by)
                   SELECT %s, 'sale', %s,
                          stock_quantity + %s, stock_quantity,
                          %s, %s
                   FROM books WHERE book_id = %s""",
                (book_id, -quantity, quantity, f"Sale #{invoice_id}", user_id, book_id)
            )

        conn.commit()
        return invoice_id

    except Exception as e:
        if conn:
            conn.rollback()
        raise e
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()


def get_sale_by_id(invoice_id: int):
    """Return invoice header + customer info."""
    rows = execute_query("""
        SELECT s.*, c.name AS customer_name, c.phone AS customer_phone,
               u.full_name AS staff_name
        FROM sales s
        LEFT JOIN customers c ON s.customer_id = c.customer_id
        LEFT JOIN users u ON s.user_id = u.user_id
        WHERE s.invoice_id = %s
    """, (invoice_id,), fetch=True)
    return rows[0] if rows else None


def get_sale_items(invoice_id: int):
    """Return all line items for an invoice."""
    return execute_query("""
        SELECT si.*, b.title, b.author, b.isbn
        FROM sale_items si
        JOIN books b ON si.book_id = b.book_id
        WHERE si.invoice_id = %s
    """, (invoice_id,), fetch=True)


def get_all_sales(start_date=None, end_date=None, limit=100):
    """Return sales list with optional date range filter."""
    query  = """
        SELECT s.invoice_id, s.sale_date, s.total_amount, s.payment_method,
               c.name AS customer_name, u.full_name AS staff_name
        FROM sales s
        LEFT JOIN customers c ON s.customer_id = c.customer_id
        LEFT JOIN users u ON s.user_id = u.user_id
        WHERE 1=1
    """
    params = []
    if start_date:
        query += " AND DATE(s.sale_date) >= %s"
        params.append(start_date)
    if end_date:
        query += " AND DATE(s.sale_date) <= %s"
        params.append(end_date)
    query += f" ORDER BY s.sale_date DESC LIMIT {int(limit)}"
    return execute_query(query, tuple(params), fetch=True)
