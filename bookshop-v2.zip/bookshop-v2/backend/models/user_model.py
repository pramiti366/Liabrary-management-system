"""
user_model.py - User Database Operations
=========================================
All database interactions for the users table.
"""

from database.db_connection import execute_query, get_connection
from utils.auth_utils import hash_password, verify_password


def find_user_by_username(username: str):
    """Return user row by username, or None."""
    rows = execute_query(
        "SELECT * FROM users WHERE username = %s AND is_active = TRUE",
        (username,), fetch=True
    )
    return rows[0] if rows else None


def find_user_by_id(user_id: int):
    """Return user row by ID, or None."""
    rows = execute_query(
        "SELECT user_id, username, full_name, email, role, is_active, created_at "
        "FROM users WHERE user_id = %s",
        (user_id,), fetch=True
    )
    return rows[0] if rows else None


def get_all_users():
    """Return all users (exclude password hash)."""
    return execute_query(
        "SELECT user_id, username, full_name, email, role, is_active, created_at "
        "FROM users ORDER BY created_at DESC",
        fetch=True
    )


def create_user(username, password, full_name, email, role='staff'):
    """Insert a new user. Returns new user_id."""
    pw_hash = hash_password(password)
    return execute_query(
        "INSERT INTO users (username, password_hash, full_name, email, role) "
        "VALUES (%s, %s, %s, %s, %s)",
        (username, pw_hash, full_name, email, role)
    )


def update_user_role(user_id: int, new_role: str):
    """Update a user's role."""
    execute_query(
        "UPDATE users SET role = %s WHERE user_id = %s",
        (new_role, user_id)
    )


def deactivate_user(user_id: int):
    """Soft-delete: set is_active = FALSE."""
    execute_query(
        "UPDATE users SET is_active = FALSE WHERE user_id = %s",
        (user_id,)
    )


def authenticate_user(username: str, password: str):
    """
    Verify credentials.
    Returns user dict on success, None on failure.
    """
    user = find_user_by_username(username)
    if user and verify_password(password, user['password_hash']):
        return user
    return None
