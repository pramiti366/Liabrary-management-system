"""
inventory_model.py - Inventory Database Operations
====================================================
"""

from database.db_connection import execute_query, get_connection


def get_inventory_log(book_id=None, limit=200):
    """Return inventory movement log, optionally filtered by book."""
    query = """
        SELECT i.*, b.title AS book_title, u.full_name AS staff_name
        FROM inventory i
        JOIN books b ON i.book_id = b.book_id
        LEFT JOIN users u ON i.created_by = u.user_id
        WHERE 1=1
    """
    params = []
    if book_id:
        query += " AND i.book_id = %s"
        params.append(book_id)
    query += f" ORDER BY i.created_at DESC LIMIT {int(limit)}"
    return execute_query(query, tuple(params), fetch=True)


def add_stock(book_id: int, quantity: int, notes: str, user_id: int):
    """
    Restock: add quantity to a book and log the movement.
    """
    conn   = None
    cursor = None
    try:
        conn   = get_connection()
        cursor = conn.cursor(dictionary=True)

        # Get current stock
        cursor.execute("SELECT stock_quantity FROM books WHERE book_id = %s", (book_id,))
        row = cursor.fetchone()
        if not row:
            raise Exception(f"Book {book_id} not found")

        before = row['stock_quantity']
        after  = before + quantity

        # Update stock
        cursor.execute(
            "UPDATE books SET stock_quantity = %s WHERE book_id = %s",
            (after, book_id)
        )

        # Log movement
        cursor.execute(
            """INSERT INTO inventory
               (book_id, change_type, quantity_change, quantity_before, quantity_after, notes, created_by)
               VALUES (%s, 'restock', %s, %s, %s, %s, %s)""",
            (book_id, quantity, before, after, notes, user_id)
        )

        conn.commit()
    except Exception as e:
        if conn: conn.rollback()
        raise e
    finally:
        if cursor: cursor.close()
        if conn:   conn.close()
