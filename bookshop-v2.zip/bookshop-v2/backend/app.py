"""
app.py - Book Shop Management System v2
========================================
Flask serves both the REST API AND the single-page frontend app.
- GET /        → serves the SPA (index.html from frontend/)
- GET /api/... → REST endpoints
"""

from flask import Flask, jsonify, send_from_directory
from flask_cors import CORS
import os
from config import ActiveConfig

from routes.auth_routes      import auth_bp
from routes.book_routes      import book_bp
from routes.customer_routes  import customer_bp
from routes.sales_routes     import sales_bp
from routes.inventory_routes import inventory_bp
from routes.report_routes    import report_bp

# Frontend folder is one level up: ../frontend
FRONTEND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'frontend')


def create_app():
    app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path='')
    app.config.from_object(ActiveConfig)

    CORS(app, resources={r"/api/*": {"origins": "*"}})

    # Register API blueprints
    app.register_blueprint(auth_bp,       url_prefix='/api')
    app.register_blueprint(book_bp,       url_prefix='/api')
    app.register_blueprint(customer_bp,   url_prefix='/api')
    app.register_blueprint(sales_bp,      url_prefix='/api')
    app.register_blueprint(inventory_bp,  url_prefix='/api')
    app.register_blueprint(report_bp,     url_prefix='/api')

    # Health check
    @app.route('/api/health')
    def health():
        return jsonify({'status': 'ok', 'version': '2.0'})

    # Serve the SPA for ALL non-API routes (client-side routing)
    @app.route('/', defaults={'path': ''})
    @app.route('/<path:path>')
    def serve_spa(path):
        # If it's a real static file, serve it
        full = os.path.join(FRONTEND_DIR, path)
        if path and os.path.exists(full):
            return send_from_directory(FRONTEND_DIR, path)
        # Otherwise serve index.html (SPA handles routing)
        return send_from_directory(FRONTEND_DIR, 'index.html')

    @app.errorhandler(404)
    def not_found(e):
        return jsonify({'error': 'Not found'}), 404

    @app.errorhandler(500)
    def server_error(e):
        return jsonify({'error': 'Internal server error'}), 500

    return app


if __name__ == '__main__':
    app = create_app()

    if ActiveConfig.SCHEDULER_ENABLED:
        from scheduler import start_scheduler
        start_scheduler()

    print("\n" + "="*55)
    print("  📚  Book Shop Management System v2")
    print("  🌐  Open: http://localhost:5000")
    print("  🔑  Admin: admin / admin123")
    print("="*55 + "\n")

    app.run(host='0.0.0.0', port=5000, debug=ActiveConfig.DEBUG)
