"""
seed_users.py - Create demo users with properly hashed passwords
================================================================
Run this AFTER loading schema.sql if the SQL seed doesn't work.

Usage:
    cd backend
    python seed_users.py
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database.db_connection import execute_query
from utils.auth_utils import hash_password

print("Creating demo users with hashed passwords...")

users = [
    ('admin',  'admin123',  'System Administrator', 'admin@bookshop.com',  'admin'),
    ('staff1', 'staff123',  'Jane Smith',           'jane@bookshop.com',   'staff'),
]

# Clear existing users
execute_query("DELETE FROM users WHERE username IN ('admin', 'staff1')")

for username, password, full_name, email, role in users:
    pw_hash = hash_password(password)
    execute_query(
        "INSERT INTO users (username, password_hash, full_name, email, role) VALUES (%s,%s,%s,%s,%s)",
        (username, pw_hash, full_name, email, role)
    )
    print(f"  ✔ Created user: {username} (role: {role})")

print("\n✅ Done! Demo credentials:")
print("   Admin: admin / admin123")
print("   Staff: staff1 / staff123")
