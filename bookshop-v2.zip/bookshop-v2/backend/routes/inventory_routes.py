"""
inventory_routes.py - Inventory API Endpoints
"""
from flask import Blueprint, request, jsonify
from services.inventory_service import restock_book, get_inventory_movements
from utils.auth_utils import login_required

inventory_bp = Blueprint('inventory', __name__)

@inventory_bp.route('/inventory', methods=['GET'])
@login_required
def get_movements(current_user):
    movements = get_inventory_movements(
        book_id=request.args.get('book_id'),
        limit=int(request.args.get('limit', 200))
    )
    return jsonify(movements), 200

@inventory_bp.route('/inventory/restock', methods=['POST'])
@login_required
def restock(current_user):
    data = request.get_json()
    if not data or not data.get('book_id') or not data.get('quantity'):
        return jsonify({'error': 'book_id and quantity are required.'}), 400
    try:
        result = restock_book(
            book_id  = int(data['book_id']),
            quantity = int(data['quantity']),
            notes    = data.get('notes', ''),
            user_id  = current_user['user_id'],
        )
        return jsonify(result), 200
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500
