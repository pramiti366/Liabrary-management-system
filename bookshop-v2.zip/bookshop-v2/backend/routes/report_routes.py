"""
report_routes.py - Report API Endpoints
"""
import json
from flask import Blueprint, request, jsonify, Response
from services.report_service import (
    get_daily_report, get_monthly_report,
    get_yearly_report, get_low_stock_report, report_to_csv
)
from utils.auth_utils import login_required
from datetime import date

report_bp = Blueprint('reports', __name__)

@report_bp.route('/reports/daily', methods=['GET'])
@login_required
def daily(current_user):
    d = request.args.get('date', date.today().isoformat())
    fmt = request.args.get('format', 'json')
    data = get_daily_report(d)
    if fmt == 'csv':
        csv_str = report_to_csv(data, 'top_books')
        return Response(csv_str, mimetype='text/csv',
                        headers={'Content-Disposition': f'attachment;filename=daily_{d}.csv'})
    return jsonify(data), 200

@report_bp.route('/reports/monthly', methods=['GET'])
@login_required
def monthly(current_user):
    today = date.today()
    year  = int(request.args.get('year',  today.year))
    month = int(request.args.get('month', today.month))
    fmt   = request.args.get('format', 'json')
    data  = get_monthly_report(year, month)
    if fmt == 'csv':
        csv_str = report_to_csv(data, 'daily_data')
        return Response(csv_str, mimetype='text/csv',
                        headers={'Content-Disposition': f'attachment;filename=monthly_{year}_{month}.csv'})
    return jsonify(data), 200

@report_bp.route('/reports/yearly', methods=['GET'])
@login_required
def yearly(current_user):
    year = int(request.args.get('year', date.today().year))
    fmt  = request.args.get('format', 'json')
    data = get_yearly_report(year)
    if fmt == 'csv':
        csv_str = report_to_csv(data, 'monthly_data')
        return Response(csv_str, mimetype='text/csv',
                        headers={'Content-Disposition': f'attachment;filename=yearly_{year}.csv'})
    return jsonify(data), 200

@report_bp.route('/reports/low-stock', methods=['GET'])
@login_required
def low_stock(current_user):
    fmt  = request.args.get('format', 'json')
    data = get_low_stock_report()
    if fmt == 'csv':
        csv_str = report_to_csv(data, 'low_stock_books')
        return Response(csv_str, mimetype='text/csv',
                        headers={'Content-Disposition': 'attachment;filename=low_stock.csv'})
    return jsonify(data), 200
