"""
customer_routes.py - Customer API Endpoints
"""
from flask import Blueprint, request, jsonify
from models.customer_model import (
    get_all_customers, get_customer_by_id,
    create_customer, update_customer, get_customer_purchase_history
)
from utils.auth_utils import login_required

customer_bp = Blueprint('customers', __name__)

@customer_bp.route('/customers', methods=['GET'])
@login_required
def list_customers(current_user):
    customers = get_all_customers(search=request.args.get('search'))
    return jsonify(customers), 200

@customer_bp.route('/customers/<int:cid>', methods=['GET'])
@login_required
def get_customer(current_user, cid):
    c = get_customer_by_id(cid)
    if not c:
        return jsonify({'error': 'Customer not found.'}), 404
    return jsonify(c), 200

@customer_bp.route('/customers', methods=['POST'])
@login_required
def add_customer(current_user):
    data = request.get_json()
    if not data or not data.get('name'):
        return jsonify({'error': 'name is required.'}), 400
    cid = create_customer(data)
    return jsonify({'message': 'Customer added.', 'customer_id': cid}), 201

@customer_bp.route('/customers/<int:cid>', methods=['PUT'])
@login_required
def edit_customer(current_user, cid):
    data = request.get_json()
    update_customer(cid, data)
    return jsonify({'message': 'Customer updated.'}), 200

@customer_bp.route('/customers/<int:cid>/history', methods=['GET'])
@login_required
def purchase_history(current_user, cid):
    history = get_customer_purchase_history(cid)
    return jsonify(history), 200
