"""
auth_routes.py - Authentication API Endpoints
==============================================
POST /api/login    - Login and get JWT token
POST /api/register - Register new user (admin only)
GET  /api/users    - List all users (admin only)
PUT  /api/users/<id>/role - Update user role (admin only)
DELETE /api/users/<id>    - Deactivate user (admin only)
"""

from flask import Blueprint, request, jsonify
from models.user_model import (
    authenticate_user, create_user, get_all_users,
    update_user_role, deactivate_user, find_user_by_id
)
from utils.auth_utils import generate_token, login_required, admin_required

auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/login', methods=['POST'])
def login():
    """Authenticate user and return JWT token."""
    data = request.get_json()
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'error': 'Username and password are required.'}), 400

    user = authenticate_user(data['username'], data['password'])
    if not user:
        return jsonify({'error': 'Invalid credentials.'}), 401

    token = generate_token(user['user_id'], user['username'], user['role'])
    return jsonify({
        'token':    token,
        'user_id':  user['user_id'],
        'username': user['username'],
        'full_name':user['full_name'],
        'role':     user['role'],
    }), 200


@auth_bp.route('/register', methods=['POST'])
@admin_required
def register(current_user):
    """Admin only: create a new user."""
    data = request.get_json()
    required = ['username', 'password', 'full_name', 'email']
    for field in required:
        if not data.get(field):
            return jsonify({'error': f'{field} is required.'}), 400

    try:
        user_id = create_user(
            username  = data['username'],
            password  = data['password'],
            full_name = data['full_name'],
            email     = data['email'],
            role      = data.get('role', 'staff'),
        )
        return jsonify({'message': 'User created.', 'user_id': user_id}), 201
    except Exception as e:
        if 'Duplicate' in str(e):
            return jsonify({'error': 'Username or email already exists.'}), 409
        return jsonify({'error': str(e)}), 500


@auth_bp.route('/users', methods=['GET'])
@admin_required
def list_users(current_user):
    """Admin only: list all users."""
    users = get_all_users()
    return jsonify(users), 200


@auth_bp.route('/users/<int:user_id>/role', methods=['PUT'])
@admin_required
def change_role(current_user, user_id):
    """Admin only: update a user's role."""
    data = request.get_json()
    if not data or data.get('role') not in ('admin', 'staff'):
        return jsonify({'error': "role must be 'admin' or 'staff'."}), 400
    update_user_role(user_id, data['role'])
    return jsonify({'message': 'Role updated.'}), 200


@auth_bp.route('/users/<int:user_id>', methods=['DELETE'])
@admin_required
def delete_user(current_user, user_id):
    """Admin only: deactivate a user."""
    if user_id == current_user['user_id']:
        return jsonify({'error': 'Cannot deactivate your own account.'}), 400
    deactivate_user(user_id)
    return jsonify({'message': 'User deactivated.'}), 200


@auth_bp.route('/me', methods=['GET'])
@login_required
def me(current_user):
    """Return the currently authenticated user's info."""
    user = find_user_by_id(current_user['user_id'])
    if not user:
        return jsonify({'error': 'User not found.'}), 404
    return jsonify(user), 200
