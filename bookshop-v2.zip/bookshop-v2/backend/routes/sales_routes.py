"""
sales_routes.py - Sales & Billing API Endpoints
"""
from flask import Blueprint, request, jsonify, Response
from models.sales_model import get_all_sales, get_sale_by_id, get_sale_items
from services.billing_service import process_sale, generate_invoice_html
from utils.auth_utils import login_required

sales_bp = Blueprint('sales', __name__)

@sales_bp.route('/sales', methods=['GET'])
@login_required
def list_sales(current_user):
    sales = get_all_sales(
        start_date = request.args.get('start_date'),
        end_date   = request.args.get('end_date'),
        limit      = request.args.get('limit', 100),
    )
    return jsonify(sales), 200

@sales_bp.route('/sales/<int:invoice_id>', methods=['GET'])
@login_required
def get_sale(current_user, invoice_id):
    sale  = get_sale_by_id(invoice_id)
    items = get_sale_items(invoice_id)
    if not sale:
        return jsonify({'error': 'Invoice not found.'}), 404
    sale['items'] = items
    return jsonify(sale), 200

@sales_bp.route('/sales', methods=['POST'])
@login_required
def create_sale_route(current_user):
    data = request.get_json()
    try:
        result = process_sale(data, user_id=current_user['user_id'])
        return jsonify(result), 201
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@sales_bp.route('/sales/<int:invoice_id>/invoice', methods=['GET'])
@login_required
def invoice_html(current_user, invoice_id):
    try:
        html = generate_invoice_html(invoice_id)
        return Response(html, mimetype='text/html')
    except ValueError as e:
        return jsonify({'error': str(e)}), 404
