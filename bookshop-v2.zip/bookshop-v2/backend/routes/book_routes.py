"""
book_routes.py - Book Management API Endpoints
================================================
GET    /api/books          - List / search books
GET    /api/books/<id>     - Get single book
POST   /api/books          - Add new book
PUT    /api/books/<id>     - Update book
DELETE /api/books/<id>     - Delete book
GET    /api/categories     - List categories
POST   /api/categories     - Add category
GET    /api/publishers     - List publishers
POST   /api/publishers     - Add publisher
"""

from flask import Blueprint, request, jsonify
from models.book_model import (
    get_all_books, get_book_by_id, create_book,
    update_book, delete_book, get_low_stock_books
)
from database.db_connection import execute_query
from utils.auth_utils import login_required, admin_required

book_bp = Blueprint('books', __name__)


# ── Books ─────────────────────────────────────────────────────────────────────

@book_bp.route('/books', methods=['GET'])
@login_required
def list_books(current_user):
    search      = request.args.get('search')
    category_id = request.args.get('category_id')
    author      = request.args.get('author')
    books = get_all_books(search=search, category_id=category_id, author=author)
    return jsonify(books), 200


@book_bp.route('/books/low-stock', methods=['GET'])
@login_required
def low_stock(current_user):
    books = get_low_stock_books()
    return jsonify(books), 200


@book_bp.route('/books/<int:book_id>', methods=['GET'])
@login_required
def get_book(current_user, book_id):
    book = get_book_by_id(book_id)
    if not book:
        return jsonify({'error': 'Book not found.'}), 404
    return jsonify(book), 200


@book_bp.route('/books', methods=['POST'])
@login_required
def add_book(current_user):
    data = request.get_json()
    if not data or not data.get('title') or not data.get('author') or not data.get('price'):
        return jsonify({'error': 'title, author, and price are required.'}), 400
    try:
        book_id = create_book(data)
        return jsonify({'message': 'Book added.', 'book_id': book_id}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@book_bp.route('/books/<int:book_id>', methods=['PUT'])
@login_required
def edit_book(current_user, book_id):
    data = request.get_json()
    if not data:
        return jsonify({'error': 'No data provided.'}), 400
    try:
        update_book(book_id, data)
        return jsonify({'message': 'Book updated.'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@book_bp.route('/books/<int:book_id>', methods=['DELETE'])
@admin_required
def remove_book(current_user, book_id):
    try:
        delete_book(book_id)
        return jsonify({'message': 'Book deleted.'}), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ── Categories ────────────────────────────────────────────────────────────────

@book_bp.route('/categories', methods=['GET'])
@login_required
def list_categories(current_user):
    cats = execute_query("SELECT * FROM categories ORDER BY category_name", fetch=True)
    return jsonify(cats), 200


@book_bp.route('/categories', methods=['POST'])
@login_required
def add_category(current_user):
    data = request.get_json()
    if not data or not data.get('category_name'):
        return jsonify({'error': 'category_name is required.'}), 400
    try:
        cid = execute_query(
            "INSERT INTO categories (category_name, description) VALUES (%s, %s)",
            (data['category_name'], data.get('description', ''))
        )
        return jsonify({'message': 'Category added.', 'category_id': cid}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ── Publishers ────────────────────────────────────────────────────────────────

@book_bp.route('/publishers', methods=['GET'])
@login_required
def list_publishers(current_user):
    pubs = execute_query("SELECT * FROM publishers ORDER BY publisher_name", fetch=True)
    return jsonify(pubs), 200


@book_bp.route('/publishers', methods=['POST'])
@login_required
def add_publisher(current_user):
    data = request.get_json()
    if not data or not data.get('publisher_name'):
        return jsonify({'error': 'publisher_name is required.'}), 400
    try:
        pid = execute_query(
            "INSERT INTO publishers (publisher_name, contact_info, address) VALUES (%s, %s, %s)",
            (data['publisher_name'], data.get('contact_info', ''), data.get('address', ''))
        )
        return jsonify({'message': 'Publisher added.', 'publisher_id': pid}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500
