-- ============================================================
-- Book Shop Management System - Sample Seed Data
-- ============================================================

USE bookshop_db;

-- ============================================================
-- CATEGORIES
-- ============================================================
INSERT INTO categories (category_name, description) VALUES
('Fiction', 'Novels, short stories, and other fictional works'),
('Non-Fiction', 'Biographies, history, essays, and factual works'),
('Science & Technology', 'Programming, engineering, science textbooks'),
('Children', 'Books for kids and young adults'),
('Business', 'Management, entrepreneurship, finance books'),
('Self-Help', 'Personal development and motivational books'),
('Academic', 'College and university textbooks'),
('Comics & Manga', 'Graphic novels and manga collections');

-- ============================================================
-- PUBLISHERS
-- ============================================================
INSERT INTO publishers (publisher_name, contact_info, address) VALUES
('Penguin Random House', 'info@penguinrandomhouse.com', '1745 Broadway, New York, NY 10019'),
('HarperCollins', 'contact@harpercollins.com', '195 Broadway, New York, NY 10007'),
('O''Reilly Media', 'info@oreilly.com', '1005 Gravenstein Highway North, Sebastopol, CA 95472'),
('Pearson Education', 'contact@pearson.com', '221 River Street, Hoboken, NJ 07030'),
('Scholastic', 'info@scholastic.com', '557 Broadway, New York, NY 10012');

-- ============================================================
-- USERS  (password: admin123 for admin, staff123 for staff)
-- ============================================================
-- Passwords are bcrypt hashed - generated with bcrypt rounds=12
-- admin123 hash:
INSERT INTO users (username, password_hash, full_name, email, role) VALUES
('admin', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBpj2SyCnMpNOu', 'System Administrator', 'admin@bookshop.com', 'admin'),
('staff1', '$2b$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.ucrv3zander', 'Jane Smith', 'jane@bookshop.com', 'staff');
-- Note: Run seed_users.py to properly hash passwords if these don't work

-- ============================================================
-- BOOKS
-- ============================================================
INSERT INTO books (title, author, isbn, category_id, publisher_id, price, stock_quantity, low_stock_threshold) VALUES
('The Great Gatsby', 'F. Scott Fitzgerald', '9780743273565', 1, 1, 12.99, 25, 5),
('To Kill a Mockingbird', 'Harper Lee', '9780061935466', 1, 2, 14.99, 18, 5),
('1984', 'George Orwell', '9780451524935', 1, 1, 11.99, 30, 5),
('Python Crash Course', 'Eric Matthes', '9781593279288', 3, 3, 39.99, 15, 3),
('Clean Code', 'Robert C. Martin', '9780132350884', 3, 4, 44.99, 10, 3),
('The Lean Startup', 'Eric Ries', '9780307887894', 5, 1, 17.99, 20, 5),
('Atomic Habits', 'James Clear', '9780735211292', 6, 2, 16.99, 35, 5),
('Harry Potter and the Sorcerer''s Stone', 'J.K. Rowling', '9780439708180', 4, 5, 10.99, 40, 10),
('The Alchemist', 'Paulo Coelho', '9780062315007', 1, 2, 13.99, 22, 5),
('Sapiens', 'Yuval Noah Harari', '9780062316097', 2, 2, 18.99, 12, 5),
('Introduction to Algorithms', 'Thomas H. Cormen', '9780262033848', 7, 4, 79.99, 8, 3),
('The Pragmatic Programmer', 'Andrew Hunt', '9780135957059', 3, 4, 49.99, 4, 3),
('Rich Dad Poor Dad', 'Robert T. Kiyosaki', '9781612680194', 5, 1, 14.99, 28, 5),
('Think and Grow Rich', 'Napoleon Hill', '9781585424337', 6, 1, 12.99, 16, 5),
('JavaScript: The Good Parts', 'Douglas Crockford', '9780596517748', 3, 3, 29.99, 3, 3);

-- ============================================================
-- CUSTOMERS
-- ============================================================
INSERT INTO customers (name, phone, email, address) VALUES
('Alice Johnson', '555-0101', 'alice@email.com', '123 Oak Street, Springfield'),
('Bob Williams', '555-0102', 'bob@email.com', '456 Maple Ave, Shelbyville'),
('Carol Davis', '555-0103', 'carol@email.com', '789 Pine Road, Capital City'),
('David Martinez', '555-0104', 'david@email.com', '321 Elm Street, Ogdenville'),
('Emma Brown', '555-0105', 'emma@email.com', '654 Birch Lane, North Haverbrook'),
('Frank Wilson', '555-0106', 'frank@email.com', '987 Cedar Blvd, Brockway'),
('Grace Taylor', '555-0107', 'grace@email.com', '147 Walnut Drive, Springfield'),
('Henry Anderson', '555-0108', 'henry@email.com', '258 Chestnut Ave, Shelbyville');
