"""
db_connection.py - MySQL Database Connection Pool
==================================================
Manages the MySQL connection using mysql-connector-python.
Provides a simple get_connection() helper used across all models.
"""

import mysql.connector
from mysql.connector import pooling, Error
import sys
import os

# Add parent directory to path so we can import config
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import ActiveConfig

# ── Connection Pool (5 connections reused across requests) ───────────────────
_pool = None

def get_pool():
    """Create the connection pool once, then reuse it."""
    global _pool
    if _pool is None:
        try:
            _pool = pooling.MySQLConnectionPool(
                pool_name    = "bookshop_pool",
                pool_size    = 5,
                host         = ActiveConfig.DB_HOST,
                port         = ActiveConfig.DB_PORT,
                user         = ActiveConfig.DB_USER,
                password     = ActiveConfig.DB_PASSWORD,
                database     = ActiveConfig.DB_NAME,
                charset      = 'utf8mb4',
                autocommit   = False,
            )
            print(f"[DB] Connection pool created → {ActiveConfig.DB_HOST}/{ActiveConfig.DB_NAME}")
        except Error as e:
            print(f"[DB ERROR] Could not create pool: {e}")
            raise
    return _pool


def get_connection():
    """
    Get a connection from the pool.
    Usage:
        conn = get_connection()
        cursor = conn.cursor(dictionary=True)
        ...
        conn.commit()
        cursor.close()
        conn.close()   # Returns connection back to pool
    """
    return get_pool().get_connection()


def execute_query(query, params=None, fetch=False, many=False):
    """
    Convenience helper to run a query and optionally return results.

    Args:
        query  : SQL string with %s placeholders
        params : tuple of values
        fetch  : True to return rows (SELECT)
        many   : True to executemany() with a list of param tuples

    Returns:
        list of dicts (if fetch=True) or lastrowid (if INSERT)
    """
    conn   = None
    cursor = None
    try:
        conn   = get_connection()
        cursor = conn.cursor(dictionary=True)

        if many and params:
            cursor.executemany(query, params)
        else:
            cursor.execute(query, params or ())

        if fetch:
            result = cursor.fetchall()
            return result
        else:
            conn.commit()
            return cursor.lastrowid

    except Error as e:
        if conn:
            conn.rollback()
        raise Exception(f"Database error: {e}")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()   # Return to pool
