"""
report_service.py - Report Generation
=======================================
Generates daily, monthly, yearly, and low-stock reports.
"""

import csv
import json
import io
from datetime import datetime, date, timedelta
from database.db_connection import execute_query
from models.book_model import get_low_stock_books


# ── Daily Sales Report ────────────────────────────────────────────────────────

def get_daily_report(target_date: str = None):
    """
    Generate a daily sales summary.
    target_date: 'YYYY-MM-DD' string. Defaults to today.
    """
    if not target_date:
        target_date = date.today().isoformat()

    # Overall summary
    summary = execute_query("""
        SELECT
          COUNT(*)            AS total_invoices,
          COALESCE(SUM(total_amount), 0) AS total_revenue,
          COALESCE(AVG(total_amount), 0) AS avg_invoice_value
        FROM sales
        WHERE DATE(sale_date) = %s
    """, (target_date,), fetch=True)

    # Top books sold
    top_books = execute_query("""
        SELECT b.title, b.author,
               SUM(si.quantity)   AS units_sold,
               SUM(si.total_price) AS revenue
        FROM sale_items si
        JOIN books b ON si.book_id = b.book_id
        JOIN sales s ON si.invoice_id = s.invoice_id
        WHERE DATE(s.sale_date) = %s
        GROUP BY b.book_id
        ORDER BY units_sold DESC
        LIMIT 10
    """, (target_date,), fetch=True)

    # Payment method breakdown
    payment_breakdown = execute_query("""
        SELECT payment_method, COUNT(*) AS count, SUM(total_amount) AS revenue
        FROM sales
        WHERE DATE(sale_date) = %s
        GROUP BY payment_method
    """, (target_date,), fetch=True)

    return {
        'report_type':       'daily',
        'date':              target_date,
        'summary':           summary[0] if summary else {},
        'top_books':         _serialize(top_books),
        'payment_breakdown': _serialize(payment_breakdown),
        'generated_at':      datetime.now().isoformat(),
    }


def generate_daily_report():
    """Called by the scheduler every night."""
    data = get_daily_report()
    execute_query(
        "INSERT INTO reports (report_type, report_date, report_data) VALUES ('daily', %s, %s)",
        (date.today().isoformat(), json.dumps(data, default=str))
    )
    print(f"[Report] Daily report saved for {date.today()}")


# ── Monthly Sales Report ──────────────────────────────────────────────────────

def get_monthly_report(year: int, month: int):
    """Generate a monthly sales summary."""
    daily_data = execute_query("""
        SELECT DATE(sale_date) AS day,
               COUNT(*)        AS invoices,
               SUM(total_amount) AS revenue
        FROM sales
        WHERE YEAR(sale_date) = %s AND MONTH(sale_date) = %s
        GROUP BY DATE(sale_date)
        ORDER BY day
    """, (year, month), fetch=True)

    total = execute_query("""
        SELECT COUNT(*) AS total_invoices, COALESCE(SUM(total_amount),0) AS total_revenue
        FROM sales
        WHERE YEAR(sale_date) = %s AND MONTH(sale_date) = %s
    """, (year, month), fetch=True)

    return {
        'report_type':  'monthly',
        'year':         year,
        'month':        month,
        'summary':      total[0] if total else {},
        'daily_data':   _serialize(daily_data),
        'generated_at': datetime.now().isoformat(),
    }


# ── Yearly Revenue Report ─────────────────────────────────────────────────────

def get_yearly_report(year: int):
    """Generate a yearly revenue summary, broken down by month."""
    monthly_data = execute_query("""
        SELECT MONTH(sale_date) AS month,
               COUNT(*)         AS invoices,
               SUM(total_amount) AS revenue
        FROM sales
        WHERE YEAR(sale_date) = %s
        GROUP BY MONTH(sale_date)
        ORDER BY month
    """, (year,), fetch=True)

    total = execute_query("""
        SELECT COALESCE(SUM(total_amount),0) AS total_revenue, COUNT(*) AS total_invoices
        FROM sales
        WHERE YEAR(sale_date) = %s
    """, (year,), fetch=True)

    return {
        'report_type':   'yearly',
        'year':          year,
        'summary':       total[0] if total else {},
        'monthly_data':  _serialize(monthly_data),
        'generated_at':  datetime.now().isoformat(),
    }


# ── Low Stock Report ──────────────────────────────────────────────────────────

def get_low_stock_report():
    """Return list of books with stock at or below threshold."""
    books = get_low_stock_books()
    return {
        'report_type':  'low_stock',
        'date':         date.today().isoformat(),
        'low_stock_books': _serialize(books),
        'total_items':  len(books),
        'generated_at': datetime.now().isoformat(),
    }


# ── Export Helpers ────────────────────────────────────────────────────────────

def report_to_csv(data: dict, list_key: str) -> str:
    """Convert a report's list section to CSV string."""
    rows = data.get(list_key, [])
    if not rows:
        return ''
    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
    return output.getvalue()


# ── Scheduled Alert ───────────────────────────────────────────────────────────

def send_low_stock_alerts():
    """Called by scheduler every morning."""
    report = get_low_stock_report()
    count  = report['total_items']
    if count > 0:
        print(f"[Alert] ⚠ {count} book(s) are low on stock!")
        for book in report['low_stock_books']:
            print(f"  - {book['title']}: {book['stock_quantity']} left (threshold: {book['low_stock_threshold']})")
    else:
        print("[Alert] All stock levels OK.")


# ── Internal helper ───────────────────────────────────────────────────────────

def _serialize(rows):
    """Convert Decimal/datetime objects to JSON-serializable types."""
    result = []
    for row in rows:
        clean = {}
        for k, v in row.items():
            if hasattr(v, 'isoformat'):
                clean[k] = v.isoformat()
            elif hasattr(v, '__float__'):
                clean[k] = float(v)
            else:
                clean[k] = v
        result.append(clean)
    return result
