"""
billing_service.py - Billing & Invoice Generation
===================================================
Business logic for creating sales and generating HTML invoices.
"""

from models.sales_model import create_sale, get_sale_by_id, get_sale_items
from models.book_model import get_book_by_id
from datetime import datetime


def process_sale(data: dict, user_id: int) -> dict:
    """
    Validate and process a new sale.

    Expected data format:
    {
      "customer_id": 1,          # optional
      "discount_percent": 10,    # optional, default 0
      "payment_method": "cash",
      "notes": "...",
      "items": [
        {"book_id": 1, "quantity": 2}
      ]
    }
    """
    if not data.get('items'):
        raise ValueError("Sale must have at least one item.")

    enriched_items = []
    for item in data['items']:
        book = get_book_by_id(item['book_id'])
        if not book:
            raise ValueError(f"Book ID {item['book_id']} not found.")
        qty = int(item['quantity'])
        if qty <= 0:
            raise ValueError(f"Quantity must be positive for book ID {item['book_id']}.")
        if book['stock_quantity'] < qty:
            raise ValueError(
                f"Insufficient stock for '{book['title']}'. "
                f"Available: {book['stock_quantity']}, Requested: {qty}"
            )
        enriched_items.append({
            'book_id':    book['book_id'],
            'quantity':   qty,
            'unit_price': float(book['price']),
        })

    invoice_id = create_sale(
        customer_id     = data.get('customer_id'),
        user_id         = user_id,
        items           = enriched_items,
        discount_percent= float(data.get('discount_percent', 0)),
        payment_method  = data.get('payment_method', 'cash'),
        notes           = data.get('notes', ''),
    )

    return {'invoice_id': invoice_id, 'message': 'Sale created successfully.'}


def generate_invoice_html(invoice_id: int) -> str:
    """Generate a printable HTML invoice for the given invoice_id."""
    sale  = get_sale_by_id(invoice_id)
    items = get_sale_items(invoice_id)

    if not sale:
        raise ValueError(f"Invoice #{invoice_id} not found.")

    rows_html = ''
    for i, item in enumerate(items, 1):
        rows_html += f"""
        <tr>
          <td>{i}</td>
          <td>{item['title']}</td>
          <td>{item['author']}</td>
          <td class="center">{item['quantity']}</td>
          <td class="right">${float(item['unit_price']):.2f}</td>
          <td class="right">${float(item['total_price']):.2f}</td>
        </tr>"""

    customer_name  = sale.get('customer_name') or 'Walk-in Customer'
    customer_phone = sale.get('customer_phone') or '—'
    sale_date      = sale['sale_date']
    if hasattr(sale_date, 'strftime'):
        sale_date = sale_date.strftime('%d %B %Y, %I:%M %p')

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Invoice #{invoice_id}</title>
  <style>
    * {{ margin:0; padding:0; box-sizing:border-box; }}
    body {{ font-family: 'Segoe UI', Arial, sans-serif; font-size:14px; color:#222; padding:40px; }}
    .invoice-box {{ max-width:800px; margin:auto; border:1px solid #ddd; padding:30px; }}
    .header {{ display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:30px; }}
    .shop-name {{ font-size:28px; font-weight:bold; color:#2c3e50; }}
    .shop-sub {{ color:#666; font-size:13px; }}
    .invoice-title {{ text-align:right; }}
    .invoice-title h2 {{ font-size:24px; color:#e74c3c; }}
    .invoice-title p {{ color:#666; }}
    .info-grid {{ display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:25px; padding:15px; background:#f8f9fa; border-radius:6px; }}
    .info-block label {{ font-weight:bold; color:#555; display:block; margin-bottom:4px; font-size:12px; text-transform:uppercase; }}
    table {{ width:100%; border-collapse:collapse; margin-bottom:20px; }}
    th {{ background:#2c3e50; color:white; padding:10px 12px; text-align:left; font-size:13px; }}
    td {{ padding:10px 12px; border-bottom:1px solid #eee; }}
    tr:last-child td {{ border-bottom:none; }}
    tr:hover {{ background:#f9f9f9; }}
    .center {{ text-align:center; }}
    .right {{ text-align:right; }}
    .totals {{ margin-left:auto; width:300px; }}
    .totals table {{ margin-bottom:0; }}
    .totals td {{ padding:6px 12px; border:none; }}
    .totals .grand-total td {{ font-size:18px; font-weight:bold; color:#2c3e50; border-top:2px solid #2c3e50; }}
    .footer {{ text-align:center; margin-top:30px; color:#888; font-size:12px; border-top:1px solid #eee; padding-top:15px; }}
    .badge {{ display:inline-block; padding:3px 10px; border-radius:20px; font-size:12px; font-weight:bold; background:#27ae60; color:white; }}
    @media print {{
      body {{ padding:0; }}
      .no-print {{ display:none; }}
    }}
  </style>
</head>
<body>
<div class="invoice-box">
  <div class="header">
    <div>
      <div class="shop-name">📚 Book Shop</div>
      <div class="shop-sub">Your Favourite Book Store</div>
    </div>
    <div class="invoice-title">
      <h2>INVOICE</h2>
      <p>#{str(invoice_id).zfill(6)}</p>
      <p>{sale_date}</p>
      <span class="badge">{sale['payment_method'].upper()}</span>
    </div>
  </div>

  <div class="info-grid">
    <div class="info-block">
      <label>Bill To</label>
      <strong>{customer_name}</strong><br>
      <span>{customer_phone}</span>
    </div>
    <div class="info-block">
      <label>Staff</label>
      <strong>{sale.get('staff_name') or 'N/A'}</strong>
    </div>
  </div>

  <table>
    <thead>
      <tr>
        <th>#</th><th>Title</th><th>Author</th>
        <th class="center">Qty</th>
        <th class="right">Unit Price</th>
        <th class="right">Total</th>
      </tr>
    </thead>
    <tbody>
      {rows_html}
    </tbody>
  </table>

  <div class="totals">
    <table>
      <tr><td>Subtotal</td><td class="right">${float(sale['subtotal']):.2f}</td></tr>
      <tr><td>Discount ({sale['discount_percent']}%)</td><td class="right">-${float(sale['discount_amount']):.2f}</td></tr>
      <tr class="grand-total"><td>TOTAL</td><td class="right">${float(sale['total_amount']):.2f}</td></tr>
    </table>
  </div>

  <div class="footer">
    <p>Thank you for shopping with us! 📖</p>
    <p>Questions? Contact us at support@bookshop.com</p>
    <button class="no-print" onclick="window.print()" style="margin-top:10px;padding:8px 20px;background:#2c3e50;color:white;border:none;border-radius:4px;cursor:pointer;">🖨 Print Invoice</button>
  </div>
</div>
</body>
</html>"""
    return html
