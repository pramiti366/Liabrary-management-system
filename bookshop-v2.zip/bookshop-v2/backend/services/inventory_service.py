"""
inventory_service.py - Inventory Business Logic
================================================
"""

from models.inventory_model import add_stock, get_inventory_log
from models.book_model import get_low_stock_books


def restock_book(book_id: int, quantity: int, notes: str, user_id: int):
    """Validate and restock a book."""
    if quantity <= 0:
        raise ValueError("Restock quantity must be positive.")
    add_stock(book_id, quantity, notes or 'Manual restock', user_id)
    return {'message': f'Added {quantity} copies to stock.'}


def get_inventory_movements(book_id=None, limit=200):
    """Return inventory log entries."""
    return get_inventory_log(book_id=book_id, limit=limit)


def send_low_stock_alerts():
    """Print low-stock warnings (called by scheduler)."""
    books = get_low_stock_books()
    if books:
        print(f"[Inventory] ⚠ {len(books)} book(s) below threshold:")
        for b in books:
            print(f"  - {b['title']}: {b['stock_quantity']} left")
    return books
