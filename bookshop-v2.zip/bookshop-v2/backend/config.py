"""
config.py - Application Configuration
======================================
Central configuration file for the Book Shop Management System.
Loads settings from environment variables with sensible defaults.
"""

import os
from datetime import timedelta

class Config:
    """Base configuration class."""

    # ── Flask Secret Key (change in production!) ─────────────────────────────
    SECRET_KEY = os.environ.get('SECRET_KEY', 'bookshop-super-secret-key-2024')

    # ── JWT Settings ──────────────────────────────────────────────────────────
    JWT_SECRET_KEY = os.environ.get('JWT_SECRET_KEY', 'jwt-bookshop-secret-2024')
    JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=8)   # Tokens valid for 8 hours

    # ── MySQL Database Settings ───────────────────────────────────────────────
    DB_HOST     = os.environ.get('DB_HOST',     'localhost')
    DB_PORT     = int(os.environ.get('DB_PORT', 1729))
    DB_USER     = os.environ.get('DB_USER',     'root')
    DB_PASSWORD = os.environ.get('DB_PASSWORD', 'root')
    DB_NAME     = os.environ.get('DB_NAME',     'bookshop_db')

    # ── CORS Settings ─────────────────────────────────────────────────────────
    CORS_ORIGINS = os.environ.get('CORS_ORIGINS', '*')   # Restrict in production

    # ── Pagination ────────────────────────────────────────────────────────────
    DEFAULT_PAGE_SIZE = 20

    # ── Low Stock Threshold (fallback) ────────────────────────────────────────
    LOW_STOCK_THRESHOLD = 5

    # ── Scheduler Settings ────────────────────────────────────────────────────
    SCHEDULER_ENABLED = os.environ.get('SCHEDULER_ENABLED', 'true').lower() == 'true'
    DAILY_REPORT_TIME  = os.environ.get('DAILY_REPORT_TIME',  '23:55')  # HH:MM
    RESTOCK_CHECK_TIME = os.environ.get('RESTOCK_CHECK_TIME', '09:00')  # HH:MM


class DevelopmentConfig(Config):
    """Development-specific settings."""
    DEBUG = True
    TESTING = False


class ProductionConfig(Config):
    """Production-specific settings."""
    DEBUG = False
    TESTING = False


# Select config based on FLASK_ENV environment variable
config_map = {
    'development': DevelopmentConfig,
    'production':  ProductionConfig,
}

# Default to development if not set
ActiveConfig = config_map.get(
    os.environ.get('FLASK_ENV', 'development'),
    DevelopmentConfig
)
