"""
scheduler.py - Background Task Scheduler
==========================================
Runs in a daemon thread. Every 60 seconds it wakes up and checks
whether any scheduled tasks should be executed.

Algorithm:
  1. Start scheduler thread
  2. Store tasks in queue (via scheduler_utils)
  3. Check current system time every 60 seconds
  4. Compare scheduled task time with current time
  5. Execute task if time matches and not already run today
  6. Sleep 60 seconds
  7. Repeat
"""

import threading
import time
from utils.scheduler_utils import add_task, check_and_run_tasks


def _scheduler_loop():
    """Main loop running in the background thread."""
    print("[Scheduler] Background scheduler started.")
    while True:
        try:
            check_and_run_tasks()
        except Exception as e:
            print(f"[Scheduler] Loop error: {e}")
        time.sleep(60)   # Check every 60 seconds


def register_default_tasks():
    """
    Register all recurring tasks.
    Called once at application startup.
    """
    from services.report_service import generate_daily_report
    from services.inventory_service import send_low_stock_alerts

    # Task 1: Generate daily sales report at 23:55 every day
    add_task(
        task_name      = 'Daily Sales Report',
        scheduled_time = '23:55',
        func           = generate_daily_report,
    )

    # Task 2: Send low-stock alerts at 09:00 every day
    add_task(
        task_name      = 'Low Stock Alert',
        scheduled_time = '09:00',
        func           = send_low_stock_alerts,
    )

    print("[Scheduler] Default tasks registered.")


def start_scheduler():
    """
    Start the background scheduler thread.
    Uses daemon=True so it exits when the main app exits.
    """
    register_default_tasks()

    scheduler_thread = threading.Thread(
        target = _scheduler_loop,
        name   = 'BookShopScheduler',
        daemon = True,
    )
    scheduler_thread.start()
    print(f"[Scheduler] Thread started: {scheduler_thread.name}")
    return scheduler_thread
